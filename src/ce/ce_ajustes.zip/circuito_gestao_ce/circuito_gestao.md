## CIRCUITO DE GESTÃO CEARENSE (CDG)

O método **Circuito de Gestão Cearense** tem a perspectiva de orientar, organizar
e sistematizar os principais processos e procedimentos que definem a gestão educacional. Da mesma forma, reforça a necessidade de corresponsabilização entre as três instâncias no enfrentamento dos desafios de aprendizagem na rede, com redução das desigualdades entre os/as estudantes e entre as escolas, a partir da definição de estratégias conectadas a esses desafios, do estabelecimento de diretrizes que orientam o desenho de ações potentes e da criação de políticas que garantam uma educação pública de qualidade.

Tanto a Seduc quanto as regionais e as escolas inserem nos seus planos as dações referentes à recomposição das aprendizagens, e essas ações, ao serem executadas e registradas nos sistemas de gestão (Sigae, Sige e Sala de Situação), passam a ter dados de execução e outros, tais como frequência dos/as estudantes e notas bimestrais. Esses dados serão analisados na etapa da SMAR juntamente com outras informações do monitoramento da recomposição de forma a possibilitar análises e tomadas de decisão informadas por evidências e uma possível correção de rotas das atividades em curso ao longo do ano letivo.

A seguir, mostramos a ritualística das etapas do Circuito, que acontece em toda a
rede ao longo de cada ano letivo.

![Infográfico mostra o método Circuito de Gestão Cearense](../assets/img/circuito-de-gestao.png)


### PLANEJAMENTO
>É a etapa que concentra a elaboração do Plano de Ação nas três instâncias (Seduc, 
Crede/Sefor e escola). Ela ocorre apenas no primeiro ciclo do CdG e é entendida como o 
“coração do método. Um planejamento bem elaborado é capaz de potencializar as próximas etapas.
           

### EXECUÇÃO

>É a etapa que tem como foco a realização das ações e atividades planejadas, bem 
como o monitoramento dos indicadores estruturantes(frequência e nota dos estudantes).
A execução é contínua, realizada durante todo o ano letivo e, portanto, perpassa as demais etapas subsequentes durante os ciclos do CdG.

### CORREÇÃO DE ROTAS/COMPARTILHAMENTO DE PRÁTICAS

>É a etapa que possibilita a revisão dos Planos de Ação das escolas, Crede/Sefor e Seduc, considerando os resultados observados na SMAR.<br>

>Experiências que impactam positivamento nos indicadores estruturantes e nos objetivos estratégicos são compartilhadas entre os agentes das instâncias e refletem na melhoria do Plano na Correção de Rotas.<br>

>Na Correção de Rotas, as instâncias podem acrescentar, excluir e/ou alterar as ações planejadas, para que os resultados propostos sejam alcançados.<br>

>Esta etapa finaliza o ciclo de melhoria contínua do CdG e possibilita que um novo ciclo tenha ínicio com a execução do Plano de Ação

### SISTEMÁTICA DE MONITORAMENTO E AVALIAÇÃO DE RESULTADOS(SMAR)

>É a etapa do CdG que permite que os gestores façam uma análise dos dados de execução do 
Plano de Ação e dos indicadores estruturantes, de acordo com o período definido.

>É uma “fotografia” da situação atual, uma parada estratégica para que seja possível a realização de uma avaliação de evidências coletadas em cada instância, de acordo com os ciclos do CdG.

>No ano letivo, serão realizadas duas etapas de SMAR, sendo a segunda intitulada Parada 
Reflexiva, pois é quando se faz um balanço do ano por meio da análise de evidências que 
servirão de subsídio para o planejamento do próximo ano.