## FORMAÇÃO DE PROFESSORES/AS: FOCO NA APRENDIZAGEM

A formação continuada é um pilar estruturante da política de recomposição das aprendizagens com equidade. Mais do que ofertar cursos ou encontros pontuais, trata-se de promover processos formativos integrados ao cotidiano escolar, articulados com o uso formativo das avaliações diagnósticas, os materiais didáticos e o acompanhamento das ações pedagógicas.

A formação do **FOCO na Aprendizagem**, conduzida pela Seduc em parceria com o 
programa Cientista Chefe, ocorre em formato de cascateamento — da secretaria até
as escolas — para garantir o alcance de toda a rede. Seu objetivo é ampliar o repertório teórico-prático dos/as educadores/as sobre recomposição das aprendizagens, uso pedagógico dos MDE, análise de dados do Sisedu, planejamento de intervenções com base em habilidades essenciais, práticas de avaliação diagnóstica e formativa, devolutivas pedagógicas, metodologias ativas e escuta dos/as estudantes. O processo formativo envolve uma cadeia de responsabilidades, apresentada a seguir.

### ESCOLA SEDUC CREDE/SEFOR


**SEDUC**
>Organiza e define as pautas formativas e realiza a formação dos/as formadores/
as regionais do FOCO.
            
**CREDE/SEFOR**
>Adapta a formação de acordo com seu contexto e forma os PCAs das escolas.
<br><br>

**ESCOLA**
>O **PCA** de cada área dissemina a formação para os/as docentes nas reuniões semanais de planejamento de áreas. Docentes ajustam os planos de aula e utilizam os MDE para personalizar o ensino.

